package com.myblogapp22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myblogapp22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
