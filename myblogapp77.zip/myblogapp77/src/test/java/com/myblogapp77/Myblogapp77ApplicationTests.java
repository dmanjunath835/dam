package com.myblogapp77;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myblogapp77ApplicationTests {

	@Test
	void contextLoads() {
	}

}
