package com.myblogapp77;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myblogapp77Application {

	public static void main(String[] args) {
		SpringApplication.run(Myblogapp77Application.class, args);
	}

}
