package com.myblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myblogapp10Application {

	public static void main(String[] args) {
		SpringApplication.run(Myblogapp10Application.class, args);
	}

}
