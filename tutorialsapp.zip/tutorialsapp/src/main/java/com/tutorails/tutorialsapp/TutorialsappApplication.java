package com.tutorails.tutorialsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutorialsappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TutorialsappApplication.class, args);
	}

}
