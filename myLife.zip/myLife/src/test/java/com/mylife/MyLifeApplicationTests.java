package com.mylife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyLifeApplicationTests {

	@Test
	void contextLoads() {
	}

}
