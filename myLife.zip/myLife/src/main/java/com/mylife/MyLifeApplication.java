package com.mylife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyLifeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyLifeApplication.class, args);
	}

}
