package com.life;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myblog99Application {

	public static void main(String[] args) {
		SpringApplication.run(Myblog99Application.class, args);
	}

}
